/*
 * TWI_Config.h
 *
 *  Created on: Aug 7, 2023
 *      Author: karim
 */

#ifndef TWI_CONFIG_H_
#define TWI_CONFIG_H_



#endif /* TWI_CONFIG_H_ */
